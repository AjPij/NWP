<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use App\Models\User;

class Project extends Model
{
    protected $fillable = ['name', 'description', 'price', 'done_jobs', 'started', 'ended', 'creator' ];

	protected $casts = [
    	'started' => 'date',
    	'ended' => 'date',
		'done_jobs' => 'string',
	];

	// user that created a project
    public function creator_user()
    {
        return $this->belongsTo(User::class, 'creator');
    }

    // users assigned to a project
    public function assignedUsers()
    {
        return $this->belongsToMany(User::class, 'project_user');
    }
}
