<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Project;
use Illuminate\Support\Facades\Auth;

class ProjectController extends Controller
{
    public function create()
    {
        $users = \App\Models\User::all();
    	return view('projects.create', compact('users'));
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'name'        => 'required|string|max:255',
            'description' => 'nullable|string',
            'price'       => 'nullable|numeric',
            'done_jobs'   => 'nullable|integer',
            'started'     => 'nullable|date',
            'ended'       => 'nullable|date',
			'assigned_users'   => 'nullable|array',
        	'assigned_users.*' => 'exists:users,id',
        ]);

        $validated['creator'] = auth()->id();
		$validated['done_jobs'] = "";
        
	 	$project = Project::create($validated);

		if ($request->has('assigned_users')) {
        	$project->assignedUsers()->sync($request->assigned_users);
    	}

        return redirect()->route('dashboard')->with('success', 'Project created!');
    }

	public function myProjects()
	{
		$userId = Auth::id();

	    $projects = Project::with('creator_user', 'assignedUsers')
    	    ->where('creator', $userId)
    	    ->orWhereHas('assignedUsers', function($q) use ($userId) { 
    	        $q->where('users.id', $userId); 
    	    })
    	    ->get();
 
    	return view('projects.my-projects', compact('projects'));
	}

	public function edit(Project $project)
    {
        $user = Auth::user();

        return view('projects.edit', [
            'project' => $project,
            'isCreator' => $project->creator == $user->id
        ]);
    }

    public function update(Request $request, Project $project)
    {
        $user = Auth::user();

        if ($project->creator == $user->id) {
            $validated = $request->validate([
                'name' => 'required|string|max:255',
                'description' => 'nullable|string',
                'price' => 'nullable|numeric',
                'done_jobs' => 'nullable|string',
                'started' => 'nullable|date',
                'ended' => 'nullable|date',
            ]);
        } else {
            $validated = $request->validate([
                'done_jobs' => 'required|string',
            ]);
        }

        $project->update($validated);
        return redirect()->route('projects.my')->with('success', 'Project updated!');
    }
}
