# Projekti

This is a repo for course Advanced web programing for LV3 and LV4.

Applicatiaon uses a starter kit for authentification and registration. To do anything in the app user needs to login or register if he/she doesn't have an account.

To run the app just run:
```
php artisan serve
```

Commands bellow aren't needed to run the project (at least on my PC).
```
npm install
npm run dev
```
