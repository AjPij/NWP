<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Add Project')); ?>

        </h2>
     <?php $__env->endSlot(); ?>


    <div class="max-w-2xl mx-auto p-6">

        <h1 class="text-2xl font-bold mb-4">Create New Project</h1>

        <?php if($errors->any()): ?>
            <div class="mb-4 text-red-600">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <form method="POST" action="<?php echo e(route('projects.store')); ?>">
            <?php echo csrf_field(); ?>

            <div class="mb-3">
                <label class="block font-medium">Project Name</label>
                <input type="text" name="name" class="border rounded w-full" required>
            </div>

            <div class="mb-3">
                <label class="block font-medium">Description</label>
                <textarea name="description" class="border rounded w-full"></textarea>
            </div>

            <div class="mb-3">
                <label class="block font-medium">Price</label>
                <input type="number" name="price" class="border rounded w-full">
            </div>

            <div class="mb-3">
                <label class="block font-medium">Started</label>
                <input type="date" name="started" class="border rounded w-full">
            </div>

            <div class="mb-3">
                <label class="block font-medium">Ended</label>
                <input type="date" name="ended" class="border rounded w-full">
            </div>
			<div class="mb-3">
    			<label class="block font-medium">Assign Users</label>
    			<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        		<label class="flex items-center space-x-2 mb-1">
            		<input type="checkbox" name="assigned_users[]" value="<?php echo e($user->id); ?>">
            		<span><?php echo e($user->name); ?></span>
        		</label>
    			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</div>

            <button
                type="submit"
                class="bg-blue-600 text-black px-4 py-2 rounded"
            >
                Create
            </button>
        </form>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>

<?php /**PATH C:\Users\IP\Downloads\projekti-main\projekti-main\resources\views/projects/create.blade.php ENDPATH**/ ?>