<x-app-layout>
    <div class="max-w-3xl mx-auto p-6">
        <h1 class="text-2xl font-bold mb-4">My Projects</h1>

        @if($projects->isEmpty())
            <p>No projects yet.</p>
        @else
            <table class="border w-full">
                <thead>
                    <tr class="border-b">
                        <th class="p-2 text-left">Name</th>
                        <th class="p-2 text-left">Creator</th>
                        <th class="p-2 text-left">Assigned Users</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($projects as $project)
                        <tr class="border-b">
                            <td class="p-2">
								<a href="{{ route('projects.edit', $project) }}" class="text-blue-600 underline">
       								{{ $project->name }}
    							</a>
							</td>
                            <td class="p-2">{{ $project->creator_user->name }}</td>
                            <td class="p-2">
                                @foreach($project->assignedUsers as $user)
                                    {{ $user->name }}@if(!$loop->last), @endif
                                @endforeach
                            </td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        @endif
    </div>
</x-app-layout>

