<x-app-layout>
    <div class="max-w-3xl mx-auto p-6">
        <h1 class="text-2xl font-bold mb-4">Edit Project</h1>

        <form action="{{ route('projects.update', $project) }}" method="POST">
            @csrf
            @method('PUT')

            @if($isCreator)
                <div class="mb-3">
                    <label class="block font-medium">Name</label>
                    <input type="text" name="name" value="{{ $project->name }}" class="border rounded w-full">
                </div>

                <div class="mb-3">
                    <label class="block font-medium">Description</label>
                    <textarea name="description" class="border rounded w-full">{{ $project->description }}</textarea>
                </div>

                <div class="mb-3">
                    <label class="block font-medium">Price</label>
                    <input type="number" name="price" value="{{ $project->price }}" class="border rounded w-full">
                </div>

                <div class="mb-3">
                    <label class="block font-medium">Started</label>
                    <input type="date" name="started" value="{{ $project->started?->format('Y-m-d') }}" class="border rounded w-full">
                </div>

                <div class="mb-3">
                    <label class="block font-medium">Ended</label>
                    <input type="date" name="ended" value="{{ $project->ended?->format('Y-m-d') }}" class="border rounded w-full">
                </div>
            @endif

            <div class="mb-3">
                <label class="block font-medium">Done Jobs</label>
                <input type="text" name="done_jobs" value="{{ $project->done_jobs }}" class="border rounded w-full">
            </div>

            <button type="submit" class="bg-blue-600 text-black px-4 py-2 rounded">Save</button>
        </form>
    </div>
</x-app-layout>

