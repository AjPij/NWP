<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            {{ __('Add Project') }}
        </h2>
    </x-slot>


    <div class="max-w-2xl mx-auto p-6">

        <h1 class="text-2xl font-bold mb-4">Create New Project</h1>

        @if ($errors->any())
            <div class="mb-4 text-red-600">
                <ul>
                    @foreach ($errors->all() as $error)
                        <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
        @endif

        <form method="POST" action="{{ route('projects.store') }}">
            @csrf

            <div class="mb-3">
                <label class="block font-medium">Project Name</label>
                <input type="text" name="name" class="border rounded w-full" required>
            </div>

            <div class="mb-3">
                <label class="block font-medium">Description</label>
                <textarea name="description" class="border rounded w-full"></textarea>
            </div>

            <div class="mb-3">
                <label class="block font-medium">Price</label>
                <input type="number" name="price" class="border rounded w-full">
            </div>

            <div class="mb-3">
                <label class="block font-medium">Started</label>
                <input type="date" name="started" class="border rounded w-full">
            </div>

            <div class="mb-3">
                <label class="block font-medium">Ended</label>
                <input type="date" name="ended" class="border rounded w-full">
            </div>
			<div class="mb-3">
    			<label class="block font-medium">Assign Users</label>
    			@foreach($users as $user)
        		<label class="flex items-center space-x-2 mb-1">
            		<input type="checkbox" name="assigned_users[]" value="{{ $user->id }}">
            		<span>{{ $user->name }}</span>
        		</label>
    			@endforeach
			</div>

            <button
                type="submit"
                class="bg-blue-600 text-black px-4 py-2 rounded"
            >
                Create
            </button>
        </form>
    </div>
</x-app-layout>

