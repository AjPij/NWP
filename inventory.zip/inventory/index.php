<?php
session_start();

// Redirect to login if not authenticated
if (!isset($_SESSION["user_id"])) {
    header("Location: auth/login.php");
    exit;
}

require_once "config/db.php";

// Fetch all components from inventory table
//$stmt = $pdo->query("SELECT * FROM inventory ORDER BY location ASC");
//$components = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Fetch components from inventory table with optional search filter
$search = $_GET['search'] ?? '';

if (!empty($search)) {
    $sql = "SELECT * FROM inventory
            WHERE location LIKE :search
               OR category LIKE :search
               OR component_name LIKE :search
            ORDER BY location";

    $stmt = $pdo->prepare($sql);
    $stmt->execute(['search' => "%$search%"]);
    $components = $stmt->fetchAll(PDO::FETCH_ASSOC); // <--- fetch results
} else {
    $sql = "SELECT * FROM inventory ORDER BY location";
    $stmt = $pdo->query($sql);
    $components = $stmt->fetchAll(PDO::FETCH_ASSOC); // <--- also fetch results
}

?>

<!DOCTYPE html>
<html>

<head>
    <link rel="stylesheet" href="css/global.css">
    <link rel="stylesheet" href="css/idx.css">
    <title>Component Inventory</title>

</head>

<body>
    <div class="generic-overlay"></div>
    <div class="container">
        <div class="main-header">
            <h1 class="main-title">Component Inventory Management</h1>
        </div>

        <div class="welcome-logout">
            <h2 class="welcome-message">Welcome, <?php echo $_SESSION["username"]; ?> (Role: <?php echo $_SESSION["role"]; ?>)</h2>
            <div class="header-buttons">
                <?php if ($_SESSION['role'] === 'admin'): ?>
                    <button
                        type="button"
                        class="index-manage-users-btn"
                        onclick="window.location.href='admin/manage_users.php';">
                        Manage Users
                    </button>
                <?php endif; ?>

                <button
                    type="button"
                    class="index-logout-btn"
                    onclick="return confirm('Are you sure you want to logout?') && (window.location.href='auth/logout.php');">
                    Logout
                </button>
            </div>

        </div>

        <h3 class="inventory-title">Inventory List:</h3>

        <div class="inventory-header">
            <form method="GET" action="index.php" class="search-form">
                <input type="text" name="search" placeholder="Search components..."
                    value="<?php echo isset($_GET['search']) ? htmlspecialchars($_GET['search']) : ''; ?>">

                <button type="submit" class="search-btn">
                    🔍
                </button>

                <a href="index.php" class="search-btn" style="margin-left:5px;">✖</a>

            </form>

            <?php if ($_SESSION['role'] === 'admin'): ?>
                <button
                    type="button"
                    class="index-add-btn"
                    onclick="window.location.href='admin/add_component.php';">
                    Add New Component

                </button>
            <?php endif; ?>

        </div>

        <?php if (count($components) === 0): ?>
            <?php if (!empty($_GET['search'])): ?>
                <p>No components match your search: "<strong><?php echo htmlspecialchars($_GET['search']); ?></strong>"</p>
            <?php else: ?>
                <p>No components in inventory yet.</p>
            <?php endif; ?>
        <?php else: ?>
            <table class="list-table">
                <tr class="table-header">
                    <th>Location</th>
                    <th>Category</th>
                    <th>Component Name</th>
                    <th>Description</th>
                    <th>Quantity</th>
                    <th>Datasheet</th>
                    <?php if ($_SESSION['role'] === 'admin'): ?>
                        <th>Actions</th>
                    <?php endif; ?>

                </tr>
                <?php foreach ($components as $component): ?>
                    <tr>
                        <!--Location column-->
                        <td><?php echo htmlspecialchars($component['location']); ?></td>
                        <!--Category column-->
                        <td><?php echo htmlspecialchars($component['category']); ?></td>
                        <!--Component Name column-->
                        <td><?php echo htmlspecialchars($component['component_name']); ?></td>
                        <!--Description column-->
                        <td><?php echo htmlspecialchars($component['component_description']); ?></td>
                        <!--Quantity column-->
                        <td><?php echo (int)$component['quantity']; ?></td>
                        <!--Datasheet URL column-->
                        <td>
                            <?php if ($component['datasheet_url']): ?>
                                <a href="<?php echo htmlspecialchars($component['datasheet_url']); ?>" target="_blank">Link</a>
                            <?php else: ?>
                                N/A
                            <?php endif; ?>
                        </td>

                        <!--Actions column admin only-->
                        <?php if ($_SESSION['role'] === 'admin'): ?>

                            <td class="actions">
                                <!--Edit component button-->
                                <button
                                    type="button"
                                    class="edit-btn"
                                    onclick="window.location.href='admin/edit_component.php?id=<?php echo $component['id']; ?>'">
                                    Edit Component
                                </button>

                                <!--Delete component button-->
                                <button
                                    type="button"
                                    class="index-delete-btn"
                                    onclick="window.location.href='admin/delete_component.php?id=<?php echo $component['id']; ?>'">
                                    Delete Component
                                </button>

                            </td>
                        <?php endif; ?>
                    </tr>
                <?php endforeach; ?>
            </table>
        <?php endif; ?>

</body>
</div>

</html>