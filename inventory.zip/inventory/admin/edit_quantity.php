<?php
session_start();
require_once "../config/db.php";

// Admin only
if (!isset($_SESSION["user_id"]) || $_SESSION["role"] !== "admin") {
    die("Access denied.");
}

// Validate ID
if (!isset($_GET["id"]) || !is_numeric($_GET["id"])) {
    die("Invalid component ID.");
}

$id = (int)$_GET["id"];
$error = "";
$success = "";

// Fetch current component
$stmt = $pdo->prepare("SELECT * FROM inventory WHERE id = :id");
$stmt->execute(["id" => $id]);
$component = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$component) {
    die("Component not found.");
}

// Handle form submit
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $quantity = (int)$_POST["quantity"];

    if ($quantity < 0) {
        $error = "Quantity cannot be negative.";
    } else {
        $update = $pdo->prepare(
            "UPDATE inventory SET quantity = :quantity WHERE id = :id"
        );
        $update->execute([
            "quantity" => $quantity,
            "id" => $id
        ]);

        $success = "Quantity updated successfully.";
        $component["quantity"] = $quantity;
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Quantity</title>
</head>
<body>

<h2>Edit Quantity</h2>

<p>
<strong>Component:</strong> <?php echo htmlspecialchars($component["component_name"]); ?><br>
<strong>Location:</strong> <?php echo htmlspecialchars($component["location"]); ?>
</p>

<a href="../index.php">Back to Inventory</a> |
<a href="../auth/logout.php">Logout</a>

<?php if ($error): ?>
    <p style="color:red;"><?php echo $error; ?></p>
<?php endif; ?>

<?php if ($success): ?>
    <p style="color:green;"><?php echo $success; ?></p>
<?php endif; ?>

<form method="post">
    <label>Quantity:</label><br>
    <input type="number" name="quantity" min="0"
           value="<?php echo (int)$component["quantity"]; ?>" required>
    <br><br>

    <button type="submit">Update Quantity</button>
</form>

</body>
</html>
