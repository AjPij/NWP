<?php
session_start();
require_once "../config/db.php";

// Admin only
if (!isset($_SESSION["user_id"]) || $_SESSION["role"] !== "admin") {
    die("Access denied.");
}

// Validate ID
if (!isset($_GET["id"]) || !is_numeric($_GET["id"])) {
    die("Invalid component ID.");
}

$id = (int)$_GET["id"];
$error = "";

// Fetch component (for confirmation message)
$stmt = $pdo->prepare("SELECT component_name, location FROM inventory WHERE id = :id");
$stmt->execute(["id" => $id]);
$component = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$component) {
    die("Component not found.");
}

// Handle delete confirmation
if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $confirm_name = trim($_POST["confirm_name"] ?? '');

    if ($confirm_name === $component["component_name"]) {
        // Delete component
        $delete = $pdo->prepare("DELETE FROM inventory WHERE id = :id");
        $delete->execute(["id" => $id]);

        header("Location: ../index.php");
        exit;
    } else {
        $error = "Component name does not match. Deletion cancelled.";
    }
}
?>


<!DOCTYPE html>
<html>

<head>
    <title>Delete Component</title>
    <link rel="stylesheet" href="../css/delete_component.css">
    <link rel="stylesheet" href="../css/global.css">
</head>

<body class="delete-comp-body">
    <!-- Black overlay behind card -->
    <div class="generic-overlay"></div>

    <!-- Centered container -->
    <div class="delete-comp-container">
        <div class="delete-comp-card">
            <h2 class="delete-comp-header">Delete Component</h2>

            <form class="delete-comp-form" method="post">
                <p>
                    Are you sure you want to delete:
                    <strong><?php echo htmlspecialchars($component["component_name"]); ?></strong>
                    at location: <?php echo htmlspecialchars($component["location"]); ?>
                </p>

                <!-- Confirmation input -->
                <input
                    class="delete-comp-confirm-input"
                    type="text"
                    name="confirm_name"
                    placeholder="Enter component name to confirm"
                    required>

                <?php if (!empty($error)): ?>
                    <p style="color:red;"><?php echo $error; ?></p>
                <?php endif; ?>

                <div class="delete-comp-buttons">
                    <button
                        class="delete-comp-delete-btn"
                        type="submit">
                        Delete
                    </button>
                    <button 
                        class="delete-comp-cancel-btn"
                        type="button"
                        onclick="window.location.href='../index.php';">
                        Cancel
                    </button>
                </div>

            </form>

        </div>

    </div>


</body>

</html>