<?php
session_start();
require_once "../config/db.php";

// Only admins can access
if (!isset($_SESSION["user_id"]) || $_SESSION["role"] !== "admin") {
    die("Access denied. Admins only.");
}

$error = "";
$success = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $location = strtoupper(trim($_POST["location"]));
    $category = $_POST["category"];
    $component_name = trim($_POST["component_name"]);
    $component_description = trim($_POST["component_description"]);
    $quantity = (int)$_POST["quantity"];
    $datasheet_url = trim($_POST["datasheet_url"]);

    // Basic validation
    if (!$location || !$category || !$component_name || $quantity < 0) {
        $error = "Please fill all required fields correctly.";
    } else {
        try {
            $stmt = $pdo->prepare("INSERT INTO inventory 
                (location, category, component_name, component_description, quantity, datasheet_url)
                VALUES (:location, :category, :component_name, :component_description, :quantity, :datasheet_url)");

            $stmt->execute([
                "location" => $location,
                "category" => $category,
                "component_name" => $component_name,
                "component_description" => $component_description,
                "quantity" => $quantity,
                "datasheet_url" => $datasheet_url ?: null
            ]);

            $success = "Component added successfully!";
        } catch (PDOException $e) {
            if ($e->getCode() == 23000) { // Unique constraint failed
                $error = "A component already exists at location $location.";
            } else {
                $error = "Database error: " . $e->getMessage();
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <title>Add Component</title>
    <link rel="stylesheet" href="../css/add_component.css">
    <link rel="stylesheet" href="../css/global.css">

</head>

<body class=add-comp-body>
    <!-- Black overlay behind card -->
    <div class="generic-overlay"></div>

    <!-- Centered container -->
    <div class="add-comp-container">
        <div class="add-comp-card">

            <div class="add-comp-header">
                <h2>Add Component</h2>

                <button
                    type="button"
                    class="add-comp-back-btn"
                    onclick="window.location.href='../index.php';">
                    Back to Inventory
                </button>
            </div>

            <?php if ($error): ?>
                <p class="form-error"><?php echo $error; ?></p>
            <?php endif; ?>

            <?php if ($success): ?>
                <p class="form-success"><?php echo $success; ?></p>
            <?php endif; ?>

            <form method="post" class="add-comp-form">

                <label>Location (e.g., A1)</label>
                <input type="text" name="location" maxlength="5" required>

                <label>Category</label>
                <select name="category" required>
                    <option value="passive">Passive</option>
                    <option value="active">Active</option>
                </select>

                <label>Component Name</label>
                <input type="text" name="component_name" maxlength="100" required>

                <label>Description</label>
                <textarea name="component_description" rows="3"></textarea>

                <label>Quantity</label>
                <input type="number" name="quantity" min="0" required>

                <label>Datasheet URL</label>
                <input type="url" name="datasheet_url">

                <button type="submit" class="add-comp-btn">Add Component</button>

            </form>
        </div>
    </div>
</body>

</html>