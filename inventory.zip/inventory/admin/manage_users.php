<?php
session_start();
require_once "../config/db.php";

// Admin only
if (!isset($_SESSION["user_id"]) || $_SESSION["role"] !== "admin") {
    die("Access denied. Admins only.");
}

// Fetch all users
$stmt = $pdo->query("SELECT id, username, email, role FROM users ORDER BY username");
$users = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <title>Manage Users</title>
    <link rel="stylesheet" href="../css/manage_users.css">
    <link rel="stylesheet" href="../css/global.css">

</head>

<body>

    <div class="generic-overlay"></div>
    <div class="container">


        <div class="header-message-btn">

            <div class="header">
                <h2>Manage Users</h2>
            </div>

            <?php if (isset($_GET['error']) && $_GET['error'] === 'self_delete'): ?>
                <p
                    class="self-delete-err-msg"
                    id="self-delete-error"
                    style="color:red; font-weight:bold;">
                    You cannot delete your own account.
                </p>
            <?php endif; ?>

            <div class="header-buttons-manage-users">
                <button
                    type="button"
                    class="manage-users-back-btn"
                    onclick="window.location.href='../index.php';">
                    Back to Inventory
                </button>
            </div>
        </div>

        <div class="user-table-header">
            <button
                type="button"
                class="manage-users-add-btn"
                onclick="window.location.href='add_user.php';">
                Add New User
            </button>
        </div>
        <?php if (count($users) === 0): ?>
            <p>No users found.</p>
        <?php else: ?>

            <table class="list-table">
                <tr class="table-header">
                    <th>Username</th>
                    <th>Email</th>
                    <th>Role</th>
                    <th>Actions</th>
                </tr>

                <?php foreach ($users as $user): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($user['username']); ?></td>
                        <td><?php echo htmlspecialchars($user['email']); ?></td>
                        <td><?php echo htmlspecialchars($user['role']); ?></td>

                        <td class="actions">
                            <button
                                type="button"
                                class="edit-user-info-btn"
                                onclick="window.location.href='edit_user.php?id=<?php echo $user['id']; ?>';">
                                Edit user info
                            </button>

                            <button
                                type="button"
                                class="manage-users-delete-btn"
                                onclick="window.location.href='delete_user.php?id=<?php echo $user['id']; ?>';">
                                Delete user
                            </button>

                        </td>
                    </tr>
                <?php endforeach; ?>

            </table>

        <?php endif; ?>

    </div>

    <script>
        const errorMsg = document.getElementById('self-delete-error');

        if (errorMsg) {
            setTimeout(() => {
                errorMsg.style.transition = "opacity 0.5s ease";
                errorMsg.style.opacity = "0";

                setTimeout(() => {
                    errorMsg.remove();
                }, 500);

            }, 5000); // 5 seconds
        }
    </script>

    <script>
        document.addEventListener("DOMContentLoaded", function() {

            const errorMsg = document.getElementById('self-delete-error');

            if (errorMsg) {
                setTimeout(() => {
                    errorMsg.style.transition = "opacity 0.5s ease";
                    errorMsg.style.opacity = "0";

                    setTimeout(() => {
                        errorMsg.remove();
                    }, 500);

                }, 5000); // 5 seconds
            }

        });
    </script>


</body>

</html>