<?php
session_start();
require_once "../config/db.php";

// Admin only
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    die("Access denied.");
}

// Validate ID
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    die("Invalid user ID.");
}

$id = (int)$_GET['id'];
$error = "";

// Fetch user info
$stmt = $pdo->prepare("SELECT username, role FROM users WHERE id = :id");
$stmt->execute(['id' => $id]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$user) {
    die("User not found.");
}

// Prevent deleting yourself
// Prevent deleting yourself
if ($id === (int)$_SESSION['user_id']) {
    header("Location: manage_users.php?error=self_delete");
    exit;
}


// Handle delete confirmation
if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $confirm_username = trim($_POST["confirm_username"] ?? '');

    // Check typed username matches
    if ($confirm_username !== $user['username']) {
        $error = "Username does not match. Deletion cancelled.";
    } else {

        // Prevent deleting last admin
        if ($user['role'] === 'admin') {

            $stmt = $pdo->query("SELECT COUNT(*) FROM users WHERE role = 'admin'");
            $adminCount = $stmt->fetchColumn();

            if ($adminCount <= 1) {
                $error = "Cannot delete the last remaining admin.";
            } else {
                $delete = $pdo->prepare("DELETE FROM users WHERE id = :id");
                $delete->execute(['id' => $id]);

                header("Location: manage_users.php");
                exit;
            }

        } else {
            // Normal user delete
            $delete = $pdo->prepare("DELETE FROM users WHERE id = :id");
            $delete->execute(['id' => $id]);

            header("Location: manage_users.php");
            exit;
        }
    }
}
?>


<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <title>Delete User</title>
    <link rel="stylesheet" href="../css/delete_user.css">
    <link rel="stylesheet" href="../css/global.css">
</head>

<body class="delete-user-body">

    <!-- Black overlay -->
    <div class="generic-overlay"></div>

    <!-- Centered container -->
    <div class="delete-user-container">

        <div class="delete-user-card">

            <h2 class="delete-user-header">Delete User</h2>

            <form class="delete-user-form" method="post">

                <p>
                    Are you sure you want to delete:
                    <strong>
                        <?php echo htmlspecialchars($user["username"]); ?>
                    </strong><br>
                    Role: <?php echo htmlspecialchars($user["role"]); ?>
                </p>

                <!-- Confirmation input -->
                <input
                    class="delete-user-confirm-input"
                    type="text"
                    name="confirm_username"
                    placeholder="Enter username to confirm"
                    required>

                <?php if (!empty($error)): ?>
                    <p class="delete-user-error">
                        <?php echo $error; ?>
                    </p>
                <?php endif; ?>

                <div class="delete-user-buttons">

                    <button
                        class="delete-user-delete-btn"
                        type="submit">
                        Delete
                    </button>

                    <button
                        class="delete-user-cancel-btn"
                        type="button"
                        onclick="window.location.href='manage_users.php';">
                        Cancel
                    </button>

                </div>

            </form>

        </div>

    </div>

</body>

</html>
