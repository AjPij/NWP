<?php
session_start();
require_once "../config/db.php";

// Admin only
if (!isset($_SESSION['user_id']) || $_SESSION["role"] !== "admin") {
    die("Access denied. Admins only.");
}

// Validate ID
if (!isset($_GET['id'])) {
    die("User ID missing.");
}

$id = (int)$_GET['id'];

// Fetch user
$stmt = $pdo->prepare("SELECT * FROM users WHERE id = :id");
$stmt->execute(['id' => $id]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$user) {
    die("User not found.");
}

$error = "";
$success = "";

// Handle form submit
if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $username = trim($_POST['username']);
    $email = trim($_POST['email']);
    $role = $_POST['role'];
    $new_password = $_POST['new_password'];

    if (!$username || !$email || !$role) {
        $error = "All fields except password are required.";
    } else {

        try {

            // Update basic fields
            $stmt = $pdo->prepare("
                UPDATE users 
                SET username = :username,
                    email = :email,
                    role = :role
                WHERE id = :id
            ");

            $stmt->execute([
                'username' => $username,
                'email' => $email,
                'role' => $role,
                'id' => $id
            ]);

            // If password entered → update it
            if (!empty($new_password)) {
                $password_hash = password_hash($new_password, PASSWORD_DEFAULT);

                $stmt = $pdo->prepare("
                    UPDATE users 
                    SET password_hash = :password_hash
                    WHERE id = :id
                ");

                $stmt->execute([
                    'password_hash' => $password_hash,
                    'id' => $id
                ]);
            }

            $success = "User updated successfully.";

            // 🔥 If admin edited himself → update session data
            if ($_SESSION['user_id'] == $id) {
                $_SESSION['username'] = $username;
                $_SESSION['role'] = $role;
            }

            // Refresh user data
            $stmt = $pdo->prepare("SELECT * FROM users WHERE id = :id");
            $stmt->execute(['id' => $id]);
            $user = $stmt->fetch(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            $error = "Database error: " . $e->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <title>Edit User</title>
    <link rel="stylesheet" href="../css/global.css">
    <link rel="stylesheet" href="../css/edit_user.css">
</head>

<body class="edit-user-body">
    <!-- Black overlay behind card -->
    <div class="generic-overlay"></div>

    <!-- Centered container -->
    <div class="edit-user-container">
        <div class="edit-user-card">

            <div class="edit-user-header">
                <h2>Edit User</h2>

                <button
                    type="button"
                    class="edit-user-back-btn"
                    onclick="window.location.href='manage_users.php';">
                    Back to Manage Users
                </button>
            </div>

            <?php if ($error): ?>
                <p style="color:red;"><?php echo $error; ?></p>
            <?php endif; ?>

            <?php if ($success): ?>
                <p style="color:green;"><?php echo $success; ?></p>
            <?php endif; ?>

            <form method="post" class="edit-user-form">

                <label>Username:</label>
                <input type="text" name="username"
                    value="<?php echo htmlspecialchars($user['username']); ?>" required>

                <label>Email:</label>
                <input type="email" name="email"
                    value="<?php echo htmlspecialchars($user['email']); ?>" required>

                <label>Role:</label>
                <select name="role">
                    <option value="user" <?php if ($user['role'] == "user") echo "selected"; ?>>User</option>
                    <option value="admin" <?php if ($user['role'] == "admin") echo "selected"; ?>>Admin</option>
                </select>

                <label>New Password (leave blank to keep current):</label>
                <input type="password" name="new_password">

                <button 
                    type="submit"
                    class="edit-user-save-btn">
                    Save Changes
                </button>

            </form>

        </div>
    </div>


</body>

</html>