<?php
session_start();

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header('Location: ../index.php');
    exit;
}

require_once '../config/db.php';

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    die('Invalid component ID.');
}

$id = (int)$_GET['id'];

$sql = "SELECT * FROM inventory WHERE id = :id";
$stmt = $pdo->prepare($sql);
$stmt->execute(['id' => $id]);
$component = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$component) {
    die('Component not found.');
}

$success = "";
$error = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $location = $_POST['location'];
    $category = $_POST['category'];
    $component_name = $_POST['component_name'];
    $component_description = $_POST['description'];
    $quantity = (int)$_POST['quantity'];
    $datasheet_url = $_POST['datasheet_url'];

    try {

        $update_sql = "UPDATE inventory 
                       SET location = :location, 
                           category = :category, 
                           component_name = :component_name, 
                           component_description = :component_description, 
                           quantity = :quantity, 
                           datasheet_url = :datasheet_url 
                       WHERE id = :id";

        $update_stmt = $pdo->prepare($update_sql);
        $update_stmt->execute([
            'location' => $location,
            'category' => $category,
            'component_name' => $component_name,
            'component_description' => $component_description,
            'quantity' => $quantity,
            'datasheet_url' => $datasheet_url,
            'id' => $id
        ]);

        $success = "Component updated successfully.";

        // Refresh component data
        $stmt = $pdo->prepare("SELECT * FROM inventory WHERE id = :id");
        $stmt->execute(['id' => $id]);
        $component = $stmt->fetch(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        $error = "Database error: " . $e->getMessage();
    }
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Edit Component</title>
    <link rel="stylesheet" href="../css/global.css">
    <link rel="stylesheet" href="../css/edit_component.css">
</head>

<body class="edit-comp-body">

    <!-- Black overlay behind card -->
    <div class="generic-overlay"></div>

    <!-- Centered container -->
    <div class="edit-comp-container">

        <div class="edit-comp-card">
            <div class="edit-comp-header">
                <h2>Edit Component</h2>
                <button
                    type="button"
                    class="edit-comp-back-btn"
                    onclick="window.location.href='../index.php';">
                    Back to Inventory
                </button>
            </div>

            <?php if (!empty($error)): ?>
                <p class="form-error"><?php echo $error; ?></p>
            <?php endif; ?>

            <?php if (!empty($success)): ?>
                <p class="form-success"><?php echo $success; ?></p>
            <?php endif; ?>


            <form method="POST" class="edit-comp-form" action="">
                <label>Location:</label><br>
                <input type="text" name="location"
                    value="<?php echo htmlspecialchars($component['location']); ?>" required><br><br>

                <label>Category:</label><br>
                <select name="category" required>
                    <option value="passive" <?php if ($component['category'] === 'passive') echo 'selected'; ?>>
                        Passive
                    </option>
                    <option value="active" <?php if ($component['category'] === 'active') echo 'selected'; ?>>
                        Active
                    </option>
                </select><br><br>

                <label>Component Name:</label><br>
                <input type="text" name="component_name"
                    value="<?php echo htmlspecialchars($component['component_name']); ?>" required><br><br>

                <label>Description:</label><br>
                <textarea name="description"><?php echo htmlspecialchars($component['component_description']); ?></textarea><br><br>

                <label>Quantity:</label><br>
                <input type="number" name="quantity"
                    value="<?php echo $component['quantity']; ?>" min="0" required><br><br>

                <label>Datasheet Link:</label><br>
                <input type="url" name="datasheet_url"
                    value="<?php echo htmlspecialchars($component['datasheet_url']); ?>"><br><br>

                <button class="save-btn" type="submit">Save Changes</button>
            </form>
        </div>

    </div>
</body>

</html>