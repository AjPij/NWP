<?php
session_start();
require_once "../config/db.php";

// Only admins allowed
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    die("Access denied. Admins only.");
}

$error = "";
$success = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $username = trim($_POST['username']);
    $password = $_POST['password'];
    $role = $_POST['role'];

    // Basic validation
    if ($username === "" || $password === "" || !in_array($role, ['admin', 'user'])) {
        $error = "All fields are required.";
    } else {

        try {
            // Check if username already exists
            $checkStmt = $pdo->prepare(
                "SELECT id FROM users WHERE username = :username"
            );
            $checkStmt->execute(['username' => $username]);

            if ($checkStmt->fetch()) {
                $error = "Username already exists.";
            } else {

                // Hash password securely
                $passwordHash = password_hash($password, PASSWORD_DEFAULT);

                // Insert new user
                $insertStmt = $pdo->prepare(
                    "INSERT INTO users (username, password_hash, role)
                     VALUES (:username, :password_hash, :role)"
                );

                $insertStmt->execute([
                    'username' => $username,
                    'password_hash' => $passwordHash,
                    'role' => $role
                ]);

                $success = "User created successfully!";
            }
        } catch (PDOException $e) {
            $error = "Database error: " . $e->getMessage();
        }
    }
}
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Add User</title>
    <link rel="stylesheet" href="../css/global.css">
    <link rel="stylesheet" href="../css/add_user.css">
</head>

<body class="add-user-body">
    <!-- Black overlay behind card -->
    <div class="generic-overlay"></div>

    <!-- Centered container -->
    <div class="add-user-container">

        <div class="add-user-card">
            <div class="add-user-card-header">
                <h2 class="form-title">Add New User</h2>
                <button type="button" class="add-user-back-btn"
                    onclick="window.location.href='../admin/manage_users.php';">
                    Back to Manage Users
                </button>
            </div>

            <!-- Flash messages -->
            <?php if ($error): ?>
                <p class="flash-error"><?php echo $error; ?></p>
            <?php endif; ?>

            <?php if ($success): ?>
                <p class="flash-success"><?php echo $success; ?></p>
            <?php endif; ?>

            <form method="post" class="add-user-form">
                <label>Username:</label>
                <input type="text" name="username" required>

                <label>Password:</label>
                <input type="password" name="password" required>

                <label>Confirm Password:</label>
                <input type="password" name="confirm_password" required>

                <label>Role:</label>
                <select name="role" required>
                    <option value="user">User</option>
                    <option value="admin">Admin</option>
                </select>

                <button type="submit" class="add-user-create-user-btn">Create User</button>

            </form>

        </div>
    </div>
</body>

</html>