<?php
session_start();
require_once "../config/db.php";

// If user already logged in, redirect
if (isset($_SESSION['user_id'])) {
    header("Location: ../index.php");
    exit;
}

$error = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $username = trim($_POST['username']);
    $password = $_POST['password'];

    $stmt = $pdo->prepare("SELECT * FROM users WHERE username = :username");
    $stmt->execute(['username' => $username]);

    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($user && password_verify($password, $user['password_hash'])) {

        $_SESSION['user_id'] = $user['id'];
        $_SESSION['username'] = $user['username'];
        $_SESSION['role'] = $user['role'];

        header("Location: ../index.php");
        exit;

    } else {
        $error = "Invalid username or password.";
    }
}

?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <!--<link rel="stylesheet" href="css/global.css">-->
    <link rel="stylesheet" href="../css/login.css">
    <title>Login</title>
</head>
<body class="login-body">

    <div class="login-overlay"></div>

    <div class="login-container">
        <div class="login-card">
            <h1 class="login-title">
                K2-9 Inventory Management System
            </h1>

            <?php if ($error): ?>
                <p class="login-error"><?php echo $error; ?></p>
            <?php endif; ?>

            <form method="post" class="login-form">
                <label>Username</label>
                <input type="text" name="username" required>

                <label>Password</label>
                <input type="password" name="password" required>

                <button type="submit" class="login-btn">Login</button>
            </form>
        </div>
    </div>

</body>

</html>
