const express = require('express');
const bcrypt = require('bcrypt');
const pool = require('../db');
const router = express.Router();

// Register
router.get('/register', (req, res) => {
  res.render('register');
});
router.post('/register', async (req, res) => {
  const { username, password } = req.body;

  const hashed = await bcrypt.hash(password, 10);

  try {
    await pool.query(
      'INSERT INTO users (username, password) VALUES ($1, $2)',
      [username, hashed]
    );
    res.redirect('/auth/login');
  } catch (err) {
    console.error(err);
    res.status(400).send('User already exists');
  }
});

// Login
router.get('/login', (req, res) => {
  res.render('login');
});
router.post('/login', async (req, res) => {
  const { username, password } = req.body;

  const result = await pool.query('SELECT * FROM users WHERE username = $1', [username]);
  const user = result.rows[0];

  if (!user) return res.status(400).send('Invalid credentials');

  const match = await bcrypt.compare(password, user.password);
  if (!match) return res.status(400).send('Invalid credentials');

  req.session.userId = user.id;
  req.session.save(err => {
    if (err) return next(err);
    res.redirect('/dashboard');
  });
});

// Logout
router.get('/logout', (req, res) => {
  req.session.destroy(() => {
    res.redirect('/');
  });
});

module.exports = router;

