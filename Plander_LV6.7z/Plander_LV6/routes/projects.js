const express = require('express');
const router = express.Router();
const pool = require('../db');

// Middleware
function requireLogin(req, res, next) {
  if (!req.session.userId) return res.redirect('/auth/login');
  next();
}

async function requireProjectOwner(req, res, next) {
  const projectId = req.params.id;
  const userId = req.session.userId;

  const result = await pool.query(
    'SELECT owner FROM projects WHERE id = $1',
    [projectId]
  );

  if (result.rowCount === 0) return res.status(404).send("Project not found");
  if (result.rows[0].owner !== userId) return res.status(403).send("Forbidden");

  next();
}

async function requireProjectAccess(req, res, next) {
  const projectId = req.params.id;
  const userId = req.session.userId;

  const result = await pool.query(
    `SELECT p.id
     FROM projects p
     LEFT JOIN project_users pu ON p.id = pu.project_id
     WHERE p.id = $1 AND (p.owner = $2 OR pu.user_id = $2)`,
    [projectId, userId]
  );

  if (result.rowCount === 0) return res.status(403).send("Forbidden");

  next();
}


// LIST PROJECTS
router.get('/', requireLogin, async (req, res) => {
  const projectsRes = await pool.query(
    `SELECT DISTINCT p.*
     FROM projects p
     LEFT JOIN project_users pu ON p.id = pu.project_id
     WHERE p.owner = $1 OR pu.user_id = $1
     ORDER BY p.id DESC`,
    [req.session.userId]
  );
  const projects = projectsRes.rows;

  for (const project of projects) {
    const assignedRes = await pool.query(
      `SELECT u.id, u.username 
       FROM users u
       JOIN project_users pu ON u.id = pu.user_id
       WHERE pu.project_id = $1`,
      [project.id]
    );
    project.assignedUsers = assignedRes.rows;
  }

  res.render('projects_list', { projects, userId: req.session.userId });
});
router.get('/project/:id', requireLogin, requireProjectAccess, async (req, res) => {
  const projectRes = await pool.query(
    'SELECT * FROM projects WHERE id = $1',
    [req.params.id]
  );
  const project = projectRes.rows[0];

  const assignedRes = await pool.query(
    `SELECT u.id, u.username
     FROM users u
     JOIN project_users pu ON u.id = pu.user_id
     WHERE pu.project_id = $1`,
    [project.id]
  );
  project.assignedUsers = assignedRes.rows;

  res.render('project_view', { project });
});

// CREATE FORM
router.get('/new', requireLogin, (req, res) => {
  res.render('projects_new');
});

// CREATE PROJECT
router.post('/new', requireLogin, async (req, res) => {
  const { name, description, price, done_jobs, start_date, end_date } = req.body;

  await pool.query(
    `INSERT INTO projects(name, description, price, done_jobs, start_date, end_date, owner)
     VALUES ($1, $2, $3, $4, $5, $6, $7)`,
    [name, description, price, done_jobs, start_date, end_date, req.session.userId]
  );

  res.redirect('/projects');
});

// EDIT FORM
router.get('/:id/edit', requireLogin, requireProjectOwner, async (req, res) => {
  const result = await pool.query(
    'SELECT * FROM projects WHERE id = $1 AND owner = $2',
    [req.params.id, req.session.userId]
  );

  if (result.rowCount === 0) return res.status(404).send("Not found.");

  const project = result.rows[0];

  project.start_date = project.start_date ? project.start_date.toISOString().substring(0,10) : '';
  project.end_date = project.end_date ? project.end_date.toISOString().substring(0,10) : '';

  const allUsersRes = await pool.query(
    'SELECT id, username FROM users WHERE id != $1',
    [req.session.userId]
  );

  const assignedRes = await pool.query(
    'SELECT user_id FROM project_users WHERE project_id = $1',
    [project.id]
  );

  const assignedUserIds = assignedRes.rows.map(r => r.user_id);

  res.render('projects_edit', { project, allUsers: allUsersRes.rows, assignedUserIds });
});

// UPDATE PROJECT
router.post('/:id/edit', requireLogin, async (req, res) => {
  const { name, description, price, done_jobs, start_date, end_date } = req.body;

  const assignedUsers = Array.isArray(req.body.assigned_users) 
                        ? req.body.assigned_users.map(Number)
                        : req.body.assigned_users ? [Number(req.body.assigned_users)] : [];

  await pool.query(
    `UPDATE projects SET
       name=$1, description=$2, price=$3, done_jobs=$4, start_date=$5, end_date=$6
     WHERE id=$7 AND owner=$8`,
    [name, description, price, done_jobs, start_date, end_date, req.params.id, req.session.userId]
  );

  await pool.query('DELETE FROM project_users WHERE project_id = $1', [req.params.id]);

  for (const userId of assignedUsers) {
    await pool.query(
      'INSERT INTO project_users(project_id, user_id) VALUES ($1, $2)',
      [req.params.id, userId]
    );
  }

  res.redirect('/projects');
});

// DELETE PROJECT
router.post('/:id/delete', requireLogin, async (req, res) => {
  await pool.query(
    'DELETE FROM projects WHERE id = $1 AND owner = $2',
    [req.params.id, req.session.userId]
  );

  res.redirect('/projects');
});

module.exports = router;

