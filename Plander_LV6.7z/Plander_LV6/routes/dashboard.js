const express = require('express');
const router = express.Router();

function requireLogin(req, res, next) {
  if (!req.session.userId) return res.redirect('/auth/login');
  next();
}

router.get('/', requireLogin, (req, res) => {
  res.render('dashboard', { userId: req.session.userId });
});

module.exports = router;

