# projects-lv6

This is a repo for course Advanced web programing for LV6.

## Installation

Clone the repo.

```
git clone https://github.com/MatejBrHe/projects-lv6.git
```

Install the dependencies.

```
npm install
```

Setup .env file with your Postgres login information.

## Usage

This app uses the Postgres database so you need to start it. After you do that start the app.

```
npm start
```

Go to [localhost](http://127.0.0.1:3000/) to see the app.

The app allows users to login and register. Logedin users can create new projects. To add new members owners of the project needs to edit the project. Projects are only visible to owner and members. Only owner can edit or delete the project.
