var mongoose = require('mongoose');
mongoose.connect('mongodb://localhost/projectsdb');
require('./projects');
require('./users');