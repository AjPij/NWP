var mongoose = require('mongoose');

var projectSchema = new mongoose.Schema({
    naziv_projekta: String,
    opis_projekta: String,
    cijena_projekta: Number,
    obavljeni_poslovi: String,
    datum_pocetka: Date,
    datum_zavrsetka: Date,
    voditelji: [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }],
    clanovi_tima: [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }],
    archived: { type: Boolean, default: false }
});

mongoose.model('Project', projectSchema);