var express = require('express');
var router = express.Router();
var mongoose = require('mongoose');
var passport = require('passport');
var User = mongoose.model('User');

/* GET users listing. */
router.get('/', function(req, res, next) {
  res.send('respond with a resource');
});

// GET register page
router.get('/register', function(req, res) {
  res.render('users/register', { title: 'Register', message: req.flash('error') });
});

// POST register
router.post('/register', async function(req, res) {
  try {
    const { username, email, password } = req.body;
    console.log('Attempting to register user:', username, email);
    const user = new User({ username, email, password });
    await user.save();
    console.log('User saved successfully');
    req.login(user, function(err) {
      if (err) { 
        console.log('Login error:', err);
        req.flash('error', 'Registration successful but login failed: ' + err.message);
        return res.redirect('/users/login');
      }
      console.log('User logged in after registration');
      return res.redirect('/users/dashboard');
    });
  } catch (err) {
    console.log('Registration error:', err.message);
    console.log('Full error:', err);
    req.flash('error', 'Registration failed: ' + err.message);
    res.redirect('/users/register');
  }
});



// GET login page
router.get('/login', function(req, res) {
  res.render('users/login', { title: 'Login', message: req.flash('error') });
});

// POST login
router.post('/login', passport.authenticate('local', {
  successRedirect: '/users/dashboard',
  failureRedirect: '/users/login',
  failureFlash: true
}));

// GET logout
router.get('/logout', function(req, res) {
  req.logout(function(err) {
    if (err) { console.log('Logout error:', err); }
    res.redirect('/');
  });
});

// Middleware to check if user is authenticated
function isAuthenticated(req, res, next) {
  if (req.isAuthenticated()) {
    return next();
  }
  res.redirect('/users/login');
}

// GET dashboard
router.get('/dashboard', isAuthenticated, async function(req, res) {
  try {
    const userId = req.user._id;
    const leaderProjects = await mongoose.model('Project').find({ voditelji: userId }).populate('voditelji clanovi_tima');
    const memberProjects = await mongoose.model('Project').find({ clanovi_tima: userId }).populate('voditelji clanovi_tima');
    res.render('users/dashboard', { title: 'Dashboard', user: req.user, leaderProjects, memberProjects });
  } catch (err) {
    res.send('Error loading dashboard');
  }
});

// GET archive
router.get('/archive', isAuthenticated, async function(req, res) {
  try {
    const userId = req.user._id;
    const archivedProjects = await mongoose.model('Project').find({
      archived: true,
      $or: [{ voditelji: userId }, { clanovi_tima: userId }]
    }).populate('voditelji clanovi_tima');
    res.render('users/archive', { title: 'Archive', archivedProjects });
  } catch (err) {
    res.send('Error loading archive');
  }
});

module.exports = router;
