var express = require('express'),
    router = express.Router(),
    mongoose = require('mongoose'),
    bodyParser = require('body-parser'),
    methodOverride = require('method-override');

function isAuthenticated(req, res, next) {
  if (req.isAuthenticated()) {
    return next();
  }
  res.redirect('/users/login');
}

router.use(isAuthenticated);
router.use(bodyParser.urlencoded({ extended: true }))
router.use(methodOverride(function(req, res){
      if (req.body && typeof req.body === 'object' && '_method' in req.body) {
        var method = req.body._method
        delete req.body._method
        return method
      }
}))

router.route('/')
    .get(async function(req, res, next) {
        try {
            const projects = await mongoose.model('Project').find({}).populate('voditelji clanovi_tima');
            res.format({
                html: function(){
                    res.render('projects/index', {
                        title: 'All my Projects',
                        "projects" : projects,
                        user: req.user
                    });
                },
                json: function(){
                    res.json(projects);
                }
            });
        } catch (err) {
            return console.error(err);
        }
    })
    .post(async function(req, res) {
        try {
            const voditelji = req.body.voditelji ? req.body.voditelji.split(',').map(id => new mongoose.Types.ObjectId(id)) : [];
            const clanovi_tima = req.body.clanovi_tima ? req.body.clanovi_tima.split(',').map(id => new mongoose.Types.ObjectId(id)) : [];
            const project = await mongoose.model('Project').create({
                naziv_projekta : req.body.naziv_projekta,
                opis_projekta : req.body.opis_projekta,
                cijena_projekta : req.body.cijena_projekta,
                obavljeni_poslovi : req.body.obavljeni_poslovi,
                datum_pocetka : req.body.datum_pocetka,
                datum_zavrsetka : req.body.datum_zavrsetka,
                voditelji : voditelji,
                clanovi_tima : clanovi_tima,
                archived : req.body.archived === 'on' ? true : false
            });
            console.log('POST creating new project: ' + project);
            res.format({
                html: function(){
                    res.location("projects");
                    res.redirect("/projects");
                },
                json: function(){
                    res.json(project);
                }
            });
        } catch (err) {
            res.send("There was a problem adding the information to the database.");
        }
    });

router.get('/new', function(req, res) {
    res.render('projects/new', { title: 'Add New Project' });
});

router.param('id', async function(req, res, next, id) {
    try {
        const project = await mongoose.model('Project').findById(id).populate('voditelji clanovi_tima');
        if (!project) {
            var err = new Error('Not Found');
            err.status = 404;
            res.format({
                html: function(){
                    next(err);
                 },
                json: function(){
                       res.json({message : err.status  + ' ' + err});
                 }
            });
        } else {
            req.project = project;
            next();
        }
    } catch (err) {
        console.log(id + ' was not found');
        res.status(404)
        var err = new Error('Not Found');
        err.status = 404;
        res.format({
            html: function(){
                next(err);
             },
            json: function(){
                   res.json({message : err.status  + ' ' + err});
             }
        });
    }
});

router.route('/:id')
  .get(async function(req, res) {
    try {
        const project = req.project;
        console.log('GET Retrieving ID: ' + project._id);
        res.format({
            html: function(){
                res.render('projects/show', {
                    title: 'Project ' + project.naziv_projekta,
                    "project" : project,
                    user: req.user
                });
            },
            json: function(){
                res.json(project);
            }
        });
    } catch (err) {
        console.log('GET Error: There was a problem retrieving: ' + err);
    }
  });

router.post('/:id/add-member', async function(req, res) {
    try {
        const project = req.project;
        if (project.voditelji.some(v => v._id.toString() === req.user._id.toString())) {
            project.clanovi_tima.push(new mongoose.Types.ObjectId(req.body.novi_clan));
            await project.save();
            res.redirect("/projects/" + project._id);
        } else {
            res.send('You are not authorized to add members.');
        }
    } catch (err) {
        res.send("There was a problem adding the information to the database.");
    }
});

router.post('/:id/update-work', async function(req, res) {
    try {
        const project = req.project;
        if (project.clanovi_tima.some(m => m._id.toString() === req.user._id.toString())) {
            project.obavljeni_poslovi = req.body.obavljeni_poslovi;
            await project.save();
            res.redirect("/projects/" + project._id);
        } else {
            res.send('You are not authorized to update completed works.');
        }
    } catch (err) {
        res.send("There was a problem updating the information to the database.");
    }
});

router.route('/:id/edit')
 .get(async function(req, res) {
    try {
        const project = req.project;
        console.log('GET Retrieving ID: ' + project._id);
        // Check if user is leader
        if (project.voditelji.some(v => v._id.toString() === req.user._id.toString())) {
            res.format({
                html: function(){
                       res.render('projects/edit', {
                          title: 'Project' + project._id,
                          "project" : project
                      });
                 },
                json: function(){
                       res.json(project);
                 }
            });
        } else {
            res.send('You are not authorized to edit this project.');
        }
    } catch (err) {
        console.log('GET Error: There was a problem retrieving: ' + err);
    }
 })
	.put(async function(req, res) {
	    try {
	        const project = req.project;
	        if (project.voditelji.some(v => v._id.toString() === req.user._id.toString())) {
	            const voditelji = req.body.voditelji ? req.body.voditelji.split(',').map(id => new mongoose.Types.ObjectId(id)) : [];
	            const clanovi_tima = req.body.clanovi_tima ? req.body.clanovi_tima.split(',').map(id => new mongoose.Types.ObjectId(id)) : [];
	            project.naziv_projekta = req.body.naziv_projekta;
	            project.opis_projekta = req.body.opis_projekta;
	            project.cijena_projekta = req.body.cijena_projekta;
	            project.obavljeni_poslovi = req.body.obavljeni_poslovi;
	            project.datum_pocetka = req.body.datum_pocetka;
	            project.datum_zavrsetka = req.body.datum_zavrsetka;
	            project.voditelji = voditelji;
	            project.clanovi_tima = clanovi_tima;
	            project.archived = req.body.archived === 'on' ? true : false;
	            await project.save();
	            res.format({
	                html: function(){
	                    res.redirect("/projects/" + project._id);
	                },
	                json: function(){
	                    res.json(project);
	                }
	            });
	        } else {
	            res.send('You are not authorized to edit this project.');
	        }
	    } catch (err) {
	           res.send("There was a problem updating the information to the database: " + err);
	    }
	})
	.delete(async function (req, res){
	    try {
	        const project = req.project;
	        if (project.voditelji.some(v => v._id.toString() === req.user._id.toString())) {
	            await project.remove();
	            console.log('DELETE removing ID: ' + project._id);
	            res.format({
	                html: function(){
	                    res.redirect("/projects");
	                },
	                json: function(){
	                    res.json({message : 'deleted',
	                        item : project
	                    });
	                }
	            });
	        } else {
	            res.send('You are not authorized to delete this project.');
	        }
	    } catch (err) {
	        return console.error(err);
	    }
	});

module.exports = router;